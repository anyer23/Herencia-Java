/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ej1electrodomestico;

import entidad.Electrodomestico;
import entidad.Lavadora;
import entidad.Television;
import java.util.ArrayList;

/**
 *
 * @author monte
 */
public class Ej1Electrodomestico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        ArrayList<Electrodomestico> productos = new ArrayList<>();

        productos.add(new Lavadora(10, 2000, "azul", 'F', 20));//2600
        productos.add(new Lavadora(20, 3000, "blanco", 'A', 30));//4500

        productos.add(new Television(30, true, 5000, "blanco", 'c', 20));//6600
        productos.add(new Television(50, false, 7000, "gris", 'g', 30));//9600

        double precioTotalElectrodomestico = 0, precioLavadora = 0, precioTv = 0;

        for (Electrodomestico producto : productos) {
            double precioFinal=producto.precioFinal();
           precioTotalElectrodomestico+=precioFinal;
           
            if (producto instanceof Lavadora) {
                
                System.out.println(" precios lava " + producto.getPrecio());
               precioLavadora+=precioFinal;
            } else if (producto instanceof Television) {
                producto.precioFinal();
                System.out.println(" precios  tv" + producto.getPrecio());
               precioTv+=precioFinal;
            }

            producto.precioFinal();
            System.out.println(" precios " + producto.getPrecio());
            

        }
        System.out.println("Precio de las lavadoras "+precioLavadora);
        System.out.println("Precio de las televisiones "+precioTv);
        System.out.println("Precio total de los electrodomesticos "+precioTotalElectrodomestico);
        

    /*    System.out.println("suma lava" + sumal);
        System.out.println("suma tv" + sumat);
        //System.out.println("precio di tv1"+tv.getPrecio());

        lavadora1.precioFinal();
        lavadora2.precioFinal();

        tv.precioFinal();
        tv2.precioFinal();
        //

        System.out.println(lavadora1.toString());
        System.out.println(lavadora2.toString());
        //  tv.crearTelevisor();

        System.out.println(tv.toString());
        System.out.println(tv2.toString());
*/
    }

}
